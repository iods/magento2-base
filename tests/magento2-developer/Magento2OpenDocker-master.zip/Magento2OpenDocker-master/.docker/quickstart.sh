#!/usr/bin/bash

echo "Quickstart Start"

touch ./bash/.bash_history

cp ./newrelic/newrelic.sample.ini ./newrelic/newrelic.ini

echo "Quickstart Finish"